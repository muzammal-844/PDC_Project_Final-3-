import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import ttkbootstrap as ttk
from ttkbootstrap.constants import *
import os  # For opening another script

# Login validation logic
def login():
    username = entry_username.get()
    password = entry_password.get()
    if username == "admin" and password == "admin":
        messagebox.showinfo("Login Successful", "Welcome to the website!")
        root.destroy()  # Close the login window
        os.system("python Dashboard.py")  # Launch Dashboard
    else:
        messagebox.showerror("Login Failed", "Invalid credentials")

# "Forgot password" action
def forgot_password():
    messagebox.showinfo("Forgot Password", "Password recovery process goes here.")

# Main window
root = ttk.Window(themename="flatly")  # You can try themes like "cyborg", "minty", etc.
root.title("Login Portal")
root.geometry("800x450")
root.resizable(False, False)

# Load and display background image
bg_image = Image.open("background.jpg")  # Make sure the image is in the same folder
bg_image = bg_image.resize((800, 450), Image.Resampling.LANCZOS)
bg_photo = ImageTk.PhotoImage(bg_image)

bg_label = tk.Label(root, image=bg_photo)
bg_label.place(x=0, y=0, relwidth=1, relheight=1)

# Transparent-like center frame
frame = ttk.Frame(root, padding=20, bootstyle="light")
frame.place(relx=0.7, rely=0.5, anchor="center")  # Positioned to the right side

# Title
ttk.Label(frame, text="User Login", font=("Helvetica", 16, "bold")).pack(pady=(10, 20))

# Username
entry_username = ttk.Entry(frame, width=30)
entry_username.pack(pady=5)
entry_username.insert(0, "Username")

# Password
entry_password = ttk.Entry(frame, width=30, show="*")
entry_password.pack(pady=5)
entry_password.insert(0, "Password")

# Remember me
ttk.Checkbutton(frame, text="Remember Me").pack(pady=5)

# Login button
ttk.Button(frame, text="Login", command=login, bootstyle="primary").pack(pady=10)

# Forgot password styled like a link
forgot_label = ttk.Label(frame, text="Forgot password?", foreground="blue", cursor="hand2")
forgot_label.pack()
forgot_label.bind("<Button-1>", lambda e: forgot_password())

root.mainloop()
