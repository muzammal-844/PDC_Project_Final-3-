import tkinter as tk
from tkinter import ttk, messagebox
import subprocess
import joblib
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import seaborn as sns
import os

class MLGUI(tk.Tk):
    """
    Main GUI application for distributed ML training and evaluation.
    Allows users to preprocess data, train multiple models (Random Forest,
    Decision Tree, Naive Bayes), and evaluate their performance with plots.
    Includes enhanced UI/UX features like loading indicators and improved plot aesthetics.
    """
    def __init__(self):
        super().__init__()
        self.title("💻 ML Distributed Training GUI")
        self.geometry("1080x720")
        self.configure(bg="#f0f4f8") # Light blue-gray background for a modern feel

        # Configure ttk style for a modern look and feel
        self.style = ttk.Style()
        self.style.theme_use("clam") # 'clam' theme offers a clean appearance

        # Custom styles for buttons to enhance visual appeal and interactivity
        self.style.configure('TButton',
                             font=('Segoe UI', 10, 'bold'),
                             foreground='#34495e', # Dark blue-gray text
                             background='#ecf0f1', # Light gray background
                             padding=10,
                             relief='flat', # Flat design
                             bordercolor='#bdc3c7', # Subtle border
                             borderwidth=1)
        self.style.map('TButton',
                       background=[('active', '#bdc3c7'), # Darker on hover
                                   ('pressed', '#95a5a6')], # Even darker when pressed
                       foreground=[('active', '#2c3e50')]) # Darker text on hover

        # Initialize a label for displaying status messages (e.g., "Loading...")
        self.status_label = tk.Label(self, text="", font=("Segoe UI", 10, "italic"),
                                     bg="#f0f4f8", fg="#7f8c8d")
        self.status_label.pack(pady=5)

        self.setup_ui()

    def setup_ui(self):
        """
        Sets up the graphical user interface elements including titles, buttons,
        and the plot display area.
        """
        # Main title label for the application
        tk.Label(self, text="🔬 Distributed ML Trainer",
                 font=("Segoe UI", 22, "bold"),
                 bg="#f0f4f8", fg="#2c3e50").pack(pady=10)

        # Subtitle/description label
        tk.Label(self, text="Train & Evaluate Random Forest, Decision Tree, and Naive Bayes",
                 font=("Segoe UI", 12), bg="#f0f4f8", fg="#555").pack()

        # Frame to hold the action buttons, providing a clean layout
        btn_frame = tk.Frame(self, bg="#f0f4f8")
        btn_frame.pack(pady=20)

        # Define buttons with their text, command, and associated model type for evaluation
        # The lambda functions ensure that the correct parameters are passed when the button is clicked
        buttons = [
            ("📂 Preprocess Data", lambda: self.run_script("preprocess.py", "Preprocessing done.")),
            ("🌲 Train RF Models", lambda: self.run_multiple(["rf_model1.py", "rf_model2.py", "rf_model3.py"], "Random Forest models trained.")),
            ("🌳 Train DT Models", lambda: self.run_multiple(["dt_model1.py", "dt_model2.py", "dt_model3.py"], "Decision Tree models trained.")),
            ("📈 Train NB Models", lambda: self.run_multiple(["nb_model1.py", "nb_model2.py", "nb_model3.py"], "Naive Bayes models trained.")),
            # Calls to evaluate_model now pass the model type name for dynamic plot labeling
            ("✅ Evaluate RF", lambda: self.evaluate_model("rf_evaluate.py", "Random Forest")),
            ("✅ Evaluate DT", lambda: self.evaluate_model("dt_evaluate.py", "Decision Tree")),
            ("✅ Evaluate NB", lambda: self.evaluate_model("nb_evaluate.py", "Naive Bayes")),
        ]

        # Create and pack buttons into the button frame, arranging them horizontally
        for txt, cmd in buttons:
            ttk.Button(btn_frame, text=txt, command=cmd).pack(side="left", padx=10, ipadx=10, ipady=5)

        # Frame to display matplotlib plots, configured to expand and fill available space
        self.plot_frame = tk.Frame(self, bg="#f0f4f8", bd=2, relief="groove") # Added border for visual separation
        self.plot_frame.pack(padx=20, pady=30, fill="both", expand=True)

    def _set_status(self, message, color="#7f8c8d"):
        """Helper function to update the status label."""
        self.status_label.config(text=message, fg=color)
        self.update_idletasks() # Force GUI update

    def run_script(self, script, success_msg):
        """
        Executes a single Python script using subprocess.
        Displays success or error messages in a messagebox and updates status label.

        Args:
            script (str): The filename of the Python script to run.
            success_msg (str): Message to display on successful execution.
        """
        self._set_status(f"Running {script}...")
        try:
            # Run the script, capturing output. Use utf-8 encoding to handle Unicode characters
            # and errors="replace" to prevent UnicodeDecodeError if output contains unsupported chars.
            result = subprocess.run(["python", script], capture_output=True, text=True, encoding="utf-8", errors="replace", check=True)
            self._set_status("Operation completed.", color="#27ae60") # Green for success
            messagebox.showinfo("Success ✅", success_msg)
        except FileNotFoundError:
            self._set_status(f"Error: {script} not found.", color="#c0392b") # Red for error
            messagebox.showerror("Error", f"Script '{script}' not found. Make sure it's in the same directory.")
        except subprocess.CalledProcessError as e:
            self._set_status(f"Script {script} failed.", color="#c0392b") # Red for error
            messagebox.showerror("Script Error ❌", f"Error in {script}:\n{e.stderr}")
        except Exception as e:
            self._set_status("An unexpected error occurred.", color="#c0392b") # Red for error
            messagebox.showerror("Error", f"An unexpected error occurred: {str(e)}")
        finally:
            self._set_status("") # Clear status after operation

    def run_multiple(self, scripts, msg):
        """
        Executes multiple Python scripts sequentially.
        Displays success or error messages and updates status label.

        Args:
            scripts (list): A list of filenames of Python scripts to run.
            msg (str): Message to display on successful execution of all scripts.
        """
        total_scripts = len(scripts)
        for i, script in enumerate(scripts):
            self._set_status(f"Running {script} ({i+1}/{total_scripts})...")
            try:
                # Run each script, ensuring check=True to raise CalledProcessError on non-zero exit code
                subprocess.run(["python", script], check=True, encoding="utf-8", errors="replace")
            except subprocess.CalledProcessError as e:
                self._set_status(f"Training failed for {script}.", color="#c0392b")
                messagebox.showerror("Training Failed ❌", f"Error in {script}:\n{e.stderr}")
                self._set_status("") # Clear status on failure
                return # Stop execution if one script fails
            except FileNotFoundError:
                self._set_status(f"Error: {script} not found.", color="#c0392b")
                messagebox.showerror("Error", f"Script '{script}' not found. Check if all files exist.")
                self._set_status("") # Clear status on failure
                return
            except Exception as e:
                self._set_status("An unexpected error occurred.", color="#c0392b")
                messagebox.showerror("Error", f"An unexpected error occurred: {str(e)}")
                self._set_status("") # Clear status on failure
                return

        self._set_status("All operations completed.", color="#27ae60")
        messagebox.showinfo("Success ✅", msg)
        self._set_status("") # Clear status after all operations

    def evaluate_model(self, eval_script, model_type_name):
        """
        Runs an evaluation script, loads its results, and displays
        a confusion matrix and accuracy comparison bar chart in the GUI.

        Args:
            eval_script (str): The filename of the evaluation script to run.
            model_type_name (str): The type of model being evaluated (e.g., "Random Forest").
        """
        # First, run the evaluation script to generate/update evaluation_results.pkl
        self.run_script(eval_script, "Evaluation completed!")

        try:
            self._set_status("Loading evaluation results and generating plots...")
            # Load the evaluation results saved by the evaluation script
            acc1, acc2, acc3, ensemble_acc, report, cm = joblib.load("evaluation_results.pkl")

            # Clear any existing widgets in the plot frame before drawing new plots
            for widget in self.plot_frame.winfo_children():
                widget.destroy()

            # Create a matplotlib figure with two subplots side-by-side for clear visualization
            fig, axes = plt.subplots(1, 2, figsize=(14, 6)) # Increased figure size for better readability
            fig.patch.set_facecolor('#f0f4f8') # Match figure background to GUI background

            # Plot 1: Confusion Matrix
            # Displays the confusion matrix for the ensemble model, with annotations and a blue colormap
            sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", ax=axes[0], cbar=False, linewidths=.5, linecolor='lightgray')
            axes[0].set_title(f"Confusion Matrix ({model_type_name} Ensemble)", fontsize=16, color='#2c3e50', pad=15)
            axes[0].set_xlabel("Predicted Label", fontsize=13, color='#555', labelpad=10)
            axes[0].set_ylabel("True Label", fontsize=13, color='#555', labelpad=10)
            axes[0].tick_params(axis='x', colors='#555', labelsize=10)
            axes[0].tick_params(axis='y', colors='#555', labelsize=10, rotation=0) # Ensure y-labels are not rotated

            # Plot 2: Accuracy Comparison Bar Chart
            # Dynamically generates model names based on the model_type_name for accurate labeling
            models = [f"{model_type_name} Model 1", f"{model_type_name} Model 2", f"{model_type_name} Model 3", "Ensemble"]
            accuracies = [acc1 * 100, acc2 * 100, acc3 * 100, ensemble_acc * 100]
            
            # Use distinct colors for bars
            bar_colors = ['#5DADE2', '#2ECC71', '#F1C40F', '#E74C3C'] # Blue, Green, Yellow, Red
            bars = axes[1].bar(models, accuracies, color=bar_colors)
            
            axes[1].set_title(f"{model_type_name} Model Accuracy Comparison", fontsize=16, color='#2c3e50', pad=15)
            axes[1].set_ylim(0, 100) # Accuracy is a percentage, so limit y-axis from 0 to 100
            axes[1].set_ylabel("Accuracy (%)", fontsize=13, color='#555', labelpad=10)
            axes[1].tick_params(axis='x', colors='#555', rotation=45, labelsize=10) # Rotate x-labels for readability
            axes[1].tick_params(axis='y', colors='#555', labelsize=10)
            axes[1].grid(axis='y', linestyle='--', alpha=0.6, color='lightgray') # Lighter grid lines

            # Add accuracy values on top of each bar for precise readability
            for bar in bars:
                yval = bar.get_height()
                axes[1].text(bar.get_x() + bar.get_width()/2, yval + 1, f'{yval:.2f}%',
                             ha='center', va='bottom', fontsize=10, color='#2c3e50', weight='bold')

            plt.tight_layout(pad=3.0) # Adjust layout to prevent labels from overlapping and add overall padding

            # Embed the matplotlib figure into the Tkinter GUI's plot_frame
            canvas = FigureCanvasTkAgg(fig, master=self.plot_frame)
            canvas.draw()
            canvas.get_tk_widget().pack(fill="both", expand=True)

            # Display the overall ensemble accuracy in a messagebox
            messagebox.showinfo("📊 Evaluation Result", f"Ensemble Accuracy: {ensemble_acc * 100:.2f}%")
            self._set_status("Plots displayed.", color="#27ae60")

        except FileNotFoundError:
            self._set_status("Error: evaluation_results.pkl not found.", color="#c0392b")
            messagebox.showerror("Error", "Evaluation results file 'evaluation_results.pkl' not found. "
                                          "Please ensure the evaluation script ran successfully and created this file.")
        except joblib.UnpicklingError:
            self._set_status("Error: Could not load evaluation results.", color="#c0392b")
            messagebox.showerror("Error", "Failed to load evaluation results. The 'evaluation_results.pkl' file might be corrupted or in an unexpected format.")
        except Exception as e:
            self._set_status("An error occurred during plotting.", color="#c0392b")
            messagebox.showerror("Error", f"Failed to load or display evaluation results: {str(e)}")
        finally:
            self._set_status("") # Clear status after operation

if __name__ == "__main__":
    app = MLGUI()
    app.mainloop()
