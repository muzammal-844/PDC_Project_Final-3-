import pandas as pd
import joblib
import numpy as np
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import os

# Load test data
try:
    X_test = pd.read_csv("X_test.csv")
    y_test = pd.read_csv("y_test.csv").squeeze() # .squeeze() converts DataFrame to Series
except FileNotFoundError:
    print("Error: X_test.csv or y_test.csv not found. Please run generate_dummy_data.py first.")
    exit() # Exit if essential files are missing

# Load trained Random Forest models
try:
    model1 = joblib.load("rf_model1.pkl")
    model2 = joblib.load("rf_model2.pkl")
    model3 = joblib.load("rf_model3.pkl")
except FileNotFoundError:
    print("Error: One or more Random Forest models (rf_modelX.pkl) not found. Please train them first.")
    exit()

# Get individual predictions
pred1 = model1.predict(X_test)
pred2 = model2.predict(X_test)
pred3 = model3.predict(X_test)

# Calculate Accuracy of individual models
acc1 = accuracy_score(y_test, pred1)
acc2 = accuracy_score(y_test, pred2)
acc3 = accuracy_score(y_test, pred3)

# Get ensemble prediction using majority voting
# Stack predictions vertically, then apply mode (majority vote) along columns (axis=0)
preds = np.array([pred1, pred2, pred3])
# pd.Series(x).mode()[0] handles cases where there might be multiple modes (takes the first one)
final_preds = np.apply_along_axis(lambda x: pd.Series(x).mode()[0], axis=0, arr=preds)

# Ensemble evaluation
ensemble_acc = accuracy_score(y_test, final_preds) # Renamed 'acc' to 'ensemble_acc' for consistency
report = classification_report(y_test, final_preds, output_dict=True)
cm = confusion_matrix(y_test, final_preds)

# Save evaluation results for GUI display
# Now saving individual accuracies (acc1, acc2, acc3) along with ensemble_acc, report, and cm
joblib.dump((acc1, acc2, acc3, ensemble_acc, report, cm), "evaluation_results.pkl")

print("Random Forest Evaluation completed successfully.")
