import pandas as pd
from sklearn.ensemble import RandomForestClassifier
import joblib

# Load data chunk (change to X2.csv / X3.csv and y2.csv / y3.csv accordingly)
X = pd.read_csv("X_train_part3.csv")
y = pd.read_csv("Y_train_part3.csv").values.ravel()

# Train Random Forest model
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X, y)

# Save model (change filename accordingly for model 2 or 3)
joblib.dump(model, "rf_model3.pkl")
print("✅ RF Model 3 trained")
