import pandas as pd
from sklearn.tree import DecisionTreeClassifier
import joblib

X = pd.read_csv("X_train_part1.csv")
y = pd.read_csv("Y_train_part1.csv").values.ravel()

model = DecisionTreeClassifier(random_state=42)
model.fit(X, y)
joblib.dump(model, "dt_model1.pkl")
print("✅ Decision Tree Model 1 trained")
