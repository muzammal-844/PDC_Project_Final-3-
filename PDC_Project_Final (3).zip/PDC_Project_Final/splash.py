import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
import itertools
import subprocess

# === SETTINGS ===
IMAGE_PATH = "splash.jpg"  # Use your actual image file
LOADING_SPEED = 30
PROGRESS_STEP = 1

# === OPEN MAIN APP (login.py) ===
def open_main_app():
    splash.destroy()
    subprocess.Popen(["python", "login.py"])  # ⬅️ Launch login.py

# === PROGRESS BAR FUNCTION ===
def load_progress(value=0):
    progress['value'] = value
    percent_label.config(text=f"{value}%")
    if value < 100:
        splash.after(LOADING_SPEED, load_progress, value + PROGRESS_STEP)
    else:
        open_main_app()

# === LOADING ANIMATION ===
def animate_loading():
    dots = next(dot_cycle)
    loading_label.config(text=f"Loading Modules{dots}")
    splash.after(500, animate_loading)

# === SPLASH WINDOW ===
splash = tk.Tk()
splash.title("Splash")
splash.geometry("600x400")
splash.overrideredirect(True)

# === BACKGROUND IMAGE ===
try:
    bg_image = Image.open(IMAGE_PATH)
    bg_image = bg_image.resize((600, 400))
    bg_photo = ImageTk.PhotoImage(bg_image)
    bg_label = tk.Label(splash, image=bg_photo)
    bg_label.place(x=0, y=0, relwidth=1, relheight=1)
except:
    splash.configure(bg="white")
    tk.Label(splash, text="Image Not Found", fg="red", bg="white").pack()

# === WHITE OVERLAY FOR TEXT VISIBILITY ===
overlay = tk.Frame(splash, bg="#ffffff", bd=0)
overlay.place(x=50, y=70, width=500, height=260)

# === DOT ANIMATION ===
dot_cycle = itertools.cycle(["", ".", "..", "..."])

# === TEXT LABELS ===
title = tk.Label(splash, text="Welcome", font=("Segoe UI", 20, "bold"),
                 fg="#2c3e50", bg="#ffffff")
title.place(relx=0.5, rely=0.25, anchor="center")

loading_label = tk.Label(splash, text="Loading Modules", font=("Segoe UI", 12),
                         fg="#2c3e50", bg="#ffffff")
loading_label.place(relx=0.5, rely=0.55, anchor="center")

percent_label = tk.Label(splash, text="0%", font=("Segoe UI", 12, "bold"),
                         fg="#2c3e50", bg="#ffffff")
percent_label.place(relx=0.5, rely=0.63, anchor="center")

# === PROGRESS BAR ===
style = ttk.Style()
style.theme_use("clam")
style.configure("TProgressbar",
                thickness=12,
                troughcolor='#cccccc',
                background='#2c3e50',
                bordercolor='gray',
                lightcolor='#2c3e50',
                darkcolor='#2c3e50')

progress = ttk.Progressbar(splash, orient=tk.HORIZONTAL, length=400, mode='determinate', style="TProgressbar")
progress.place(relx=0.5, rely=0.75, anchor="center")

# === CENTER SPLASH SCREEN ===
splash.update_idletasks()
width = splash.winfo_width()
height = splash.winfo_height()
x = (splash.winfo_screenwidth() // 2) - (width // 2)
y = (splash.winfo_screenheight() // 2) - (height // 2)
splash.geometry(f"{width}x{height}+{x}+{y}")

# === START LOADING ===
animate_loading()
splash.after(500, load_progress)
splash.mainloop()
