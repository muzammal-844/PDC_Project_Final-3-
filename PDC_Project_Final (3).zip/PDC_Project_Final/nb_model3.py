import pandas as pd
from sklearn.naive_bayes import GaussianNB
import joblib

X = pd.read_csv("X_train_part3.csv")
y = pd.read_csv("Y_train_part3.csv").values.ravel()

model = GaussianNB()
model.fit(X, y)
joblib.dump(model, "nb_model3.pkl")
print("✅ Naive Bayes Model 3 trained")
