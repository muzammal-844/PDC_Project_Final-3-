import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.impute import SimpleImputer
import numpy as np
import joblib

data = pd.read_csv('Completed_Survey_500_Responses.csv')
# data = pd.read_csv("uploaded_dataset.csv")  # Use uploaded dataset
data = data.drop_duplicates()
data = data.drop(columns=[
    'Timestamp',
    '7. For what purposes do you primarily use ChatGPT? (Select all that apply)',
    '21. How has ChatGPT influenced your academic performance? ',
    '20. What other changes have you noticed in your learning habits?',
    '12. What other benefits have you experienced from using ChatGPT?'
])

def categorize_age(age):
    if age.lower() == "under 15":
        return 10
    elif age.lower() == "above 40":
        return 45
    else:
        return int(age)

data['1. What is your age?'] = data['1. What is your age?'].apply(categorize_age)
bins = [0, 15, 20, 25, 30, 35, 40, 50]
labels = [1, 2, 3, 4, 5, 6, 7]
data['Age_Group'] = pd.cut(data['1. What is your age?'], bins=bins, labels=labels, right=False)
data.drop(columns=['1. What is your age?'], inplace=True)

imputer = SimpleImputer(strategy='most_frequent')
data = pd.DataFrame(imputer.fit_transform(data), columns=data.columns)

label_encoders = {}
for col in data.select_dtypes(include='object').columns:
    le = LabelEncoder()
    data[col] = le.fit_transform(data[col])
    label_encoders[col] = le

joblib.dump(label_encoders, 'label_encoders.pkl')

X = data.drop(columns=['19. Do you find yourself relying more on AI tools since using ChatGPT?'])
y = data['19. Do you find yourself relying more on AI tools since using ChatGPT?']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

X_parts = np.array_split(X_train, 3)
y_parts = np.array_split(y_train, 3)

for i in range(3):
    X_parts[i].to_csv(f'X_train_part{i+1}.csv', index=False)
    y_parts[i].to_csv(f'y_train_part{i+1}.csv', index=False)

X_test.to_csv('X_test.csv', index=False)
y_test.to_csv('y_test.csv', index=False) 