import pandas as pd
from sklearn.tree import DecisionTreeClassifier
import joblib

X = pd.read_csv("X_train_part3.csv")
y = pd.read_csv("Y_train_part3.csv").values.ravel()

model = DecisionTreeClassifier(random_state=42)
model.fit(X, y)
joblib.dump(model, "dt_model3.pkl")
print("✅ Decision Tree Model 3 trained")
