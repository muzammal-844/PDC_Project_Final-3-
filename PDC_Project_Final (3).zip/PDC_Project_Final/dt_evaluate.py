import pandas as pd
import joblib
import numpy as np
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

# Load test data
X_test = pd.read_csv("X_test.csv")
y_test = pd.read_csv("y_test.csv")

# Load trained Decision Tree models
model1 = joblib.load("dt_model1.pkl")
model2 = joblib.load("dt_model2.pkl")
model3 = joblib.load("dt_model3.pkl")

# Get individual predictions
pred1 = model1.predict(X_test)
pred2 = model2.predict(X_test)
pred3 = model3.predict(X_test)

# Accuracy of individual models
acc1 = accuracy_score(y_test, pred1)
acc2 = accuracy_score(y_test, pred2)
acc3 = accuracy_score(y_test, pred3)

# Get ensemble prediction using majority voting
preds = np.array([pred1, pred2, pred3])
final_preds = np.apply_along_axis(lambda x: pd.Series(x).mode()[0], axis=0, arr=preds)

# Ensemble evaluation
ensemble_acc = accuracy_score(y_test, final_preds)
report = classification_report(y_test, final_preds, output_dict=True)
cm = confusion_matrix(y_test, final_preds)

# Save evaluation results for GUI display
joblib.dump((acc1, acc2, acc3, ensemble_acc, report, cm), "evaluation_results.pkl")

print("Decision Tree Evaluation completed successfully.")
